import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// POST - Create demo request
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { name, email, phone, company, employees, businessType, notes } = body;

    // Validation
    if (!name || !email || !phone) {
      return NextResponse.json(
        { success: false, error: "Name, email, and phone are required" },
        { status: 400 }
      );
    }

    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return NextResponse.json(
        { success: false, error: "Invalid email format" },
        { status: 400 }
      );
    }

    // Phone validation (Saudi format)
    const phoneRegex = /^05\d{8}$/;
    if (!phoneRegex.test(phone.replace(/\s/g, ""))) {
      return NextResponse.json(
        { success: false, error: "Invalid phone format. Use Saudi format: 05xxxxxxxx" },
        { status: 400 }
      );
    }

    // Create demo request
    const demoRequest = await db.demoRequest.create({
      data: {
        name,
        email,
        phone,
        company: company || null,
        employees: employees || null,
        businessType: businessType || null,
        notes: notes || null,
        status: "pending",
      },
    });

    return NextResponse.json({
      success: true,
      data: demoRequest,
      message: "تم استلام طلبك بنجاح، سيتواصل معك فريقنا خلال 24 ساعة",
    });
  } catch (error) {
    console.error("Error creating demo request:", error);
    return NextResponse.json(
      { success: false, error: "Failed to submit demo request" },
      { status: 500 }
    );
  }
}

// GET - Fetch demo requests (for admin)
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const status = searchParams.get("status");
    const limit = parseInt(searchParams.get("limit") || "50");
    const offset = parseInt(searchParams.get("offset") || "0");

    const where = status ? { status } : {};

    const demoRequests = await db.demoRequest.findMany({
      where,
      take: limit,
      skip: offset,
      orderBy: { createdAt: "desc" },
    });

    const total = await db.demoRequest.count({ where });

    return NextResponse.json({
      success: true,
      data: demoRequests,
      pagination: {
        total,
        limit,
        offset,
        hasMore: offset + limit < total,
      },
    });
  } catch (error) {
    console.error("Error fetching demo requests:", error);
    return NextResponse.json(
      { success: false, error: "Failed to fetch demo requests" },
      { status: 500 }
    );
  }
}
