import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// POST - Subscribe to newsletter
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { email } = body;

    if (!email) {
      return NextResponse.json(
        { success: false, error: "Email is required" },
        { status: 400 }
      );
    }

    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return NextResponse.json(
        { success: false, error: "Invalid email format" },
        { status: 400 }
      );
    }

    // Check if already subscribed
    const existing = await db.newsletterSubscriber.findUnique({
      where: { email },
    });

    if (existing) {
      if (existing.active) {
        return NextResponse.json({
          success: true,
          message: "أنت مشترك بالفعل في النشرة البريدية",
        });
      } else {
        // Reactivate subscription
        await db.newsletterSubscriber.update({
          where: { email },
          data: { active: true },
        });
        return NextResponse.json({
          success: true,
          message: "تم إعادة تفعيل اشتراكك بنجاح",
        });
      }
    }

    // Create new subscription
    await db.newsletterSubscriber.create({
      data: { email },
    });

    return NextResponse.json({
      success: true,
      message: "تم الاشتراك بنجاح في النشرة البريدية",
    });
  } catch (error) {
    console.error("Error subscribing to newsletter:", error);
    return NextResponse.json(
      { success: false, error: "Failed to subscribe" },
      { status: 500 }
    );
  }
}

// DELETE - Unsubscribe from newsletter
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const email = searchParams.get("email");

    if (!email) {
      return NextResponse.json(
        { success: false, error: "Email is required" },
        { status: 400 }
      );
    }

    await db.newsletterSubscriber.update({
      where: { email },
      data: { active: false },
    });

    return NextResponse.json({
      success: true,
      message: "تم إلغاء الاشتراك بنجاح",
    });
  } catch (error) {
    console.error("Error unsubscribing from newsletter:", error);
    return NextResponse.json(
      { success: false, error: "Failed to unsubscribe" },
      { status: 500 }
    );
  }
}
